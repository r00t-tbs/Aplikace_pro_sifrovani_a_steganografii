﻿using System.Collections.Generic;
using System;
using System.Drawing;
using System.Linq;
using System.Text;

namespace EncryptionSteganographyApp
{
    public static class LSBSteganography
    {
        public static Bitmap HideText(string text, Bitmap image)
        {
            // txt to 101010
            string binaryText = string.Join("", Encoding.ASCII.GetBytes(text)
                                    .Select(c => Convert.ToString(c, 2).PadLeft(8, '0')));
            binaryText += "00000000"; // Termination bits to mark the end of text

            int textIndex = 0;

            // Iterate over each pixel to embed the binary text
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    if (textIndex >= binaryText.Length)
                        return image; // Stop when the entire text is embedded

                    Color pixel = image.GetPixel(x, y);
                    int r = pixel.R & ~1 | (binaryText[textIndex++] - '0'); // Modify LSB of Red
                    int g = pixel.G & ~1 | (textIndex < binaryText.Length ? binaryText[textIndex++] - '0' : 0); // Green
                    int b = pixel.B & ~1 | (textIndex < binaryText.Length ? binaryText[textIndex++] - '0' : 0); // Blue

                    image.SetPixel(x, y, Color.FromArgb(r, g, b)); // Update the pixel
                }
            }
            return image;
        }

        public static string ExtractText(Bitmap image)
        {
            StringBuilder binaryText = new StringBuilder();
            Console.WriteLine($"Binary so far: {binaryText.ToString()}");
            bool stop = false;

            for (int y = 0; y < image.Height && !stop; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixel = image.GetPixel(x, y);
                    binaryText.Append(pixel.R & 1);
                    binaryText.Append(pixel.G & 1);
                    binaryText.Append(pixel.B & 1);

                    // Check for termination pattern (e.g., "00000000" marks end of text)
                    if (binaryText.Length % 8 == 0 && binaryText.ToString(binaryText.Length - 8, 8) == "00000000")
                    {
                        stop = true;
                        break;
                    }
                }
            }

            List<byte> textBytes = new List<byte>();
            for (int i = 0; i < binaryText.Length - 8; i += 8) // Exclude termination bits
            {
                string byteString = binaryText.ToString(i, 8);
                textBytes.Add(Convert.ToByte(byteString, 2));
            }

            return Encoding.ASCII.GetString(textBytes.ToArray());
        }
    }
}