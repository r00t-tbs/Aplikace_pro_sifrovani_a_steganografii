﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace EncryptionSteganographyApp
{
    public partial class Form1 : Form
    {


        private System.ComponentModel.IContainer components = null;


        private TextBox txtUserInput;
        private ComboBox cmbShiftKey;
        private TextBox txtOutput;
        private TextBox txtStegoInput;
        private TextBox txtImagePath;
        private TextBox txtStegoOutput;
        private Button btnEncrypt;
        private Button btnDecrypt;
        private Button btnEncryptHide;
        private Button btnExtractDecrypt;
        private Button btnLoadImage;
        private ProgressBar progressBar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {

            this.txtUserInput = new System.Windows.Forms.TextBox();
            this.cmbShiftKey = new System.Windows.Forms.ComboBox();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.txtStegoInput = new System.Windows.Forms.TextBox();
            this.txtImagePath = new System.Windows.Forms.TextBox();
            this.txtStegoOutput = new System.Windows.Forms.TextBox();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.btnEncryptHide = new System.Windows.Forms.Button();
            this.btnExtractDecrypt = new System.Windows.Forms.Button();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtUserInput
            // 
            this.txtUserInput.Location = new System.Drawing.Point(50, 50);
            this.txtUserInput.Name = "txtUserInput";
            this.txtUserInput.Size = new System.Drawing.Size(200, 22);
            this.txtUserInput.TabIndex = 0;
            this.txtUserInput.Text = "Enter text";
            // 
            // cmbShiftKey
            // 
            this.cmbShiftKey.Location = new System.Drawing.Point(270, 50);
            this.cmbShiftKey.Name = "cmbShiftKey";
            this.cmbShiftKey.Size = new System.Drawing.Size(100, 24);
            this.cmbShiftKey.TabIndex = 1;
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(50, 100);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(400, 22);
            this.txtOutput.TabIndex = 2;
            // 
            // txtStegoInput
            // 
            this.txtStegoInput.Location = new System.Drawing.Point(50, 200);
            this.txtStegoInput.Name = "txtStegoInput";
            this.txtStegoInput.Size = new System.Drawing.Size(300, 22);
            this.txtStegoInput.TabIndex = 3;
            this.txtStegoInput.Text = "Text to hide";
            // 
            // txtImagePath
            // 
            this.txtImagePath.Location = new System.Drawing.Point(50, 250);
            this.txtImagePath.Name = "txtImagePath";
            this.txtImagePath.Size = new System.Drawing.Size(300, 22);
            this.txtImagePath.TabIndex = 4;
            this.txtImagePath.Text = "Image file path";
            // 
            // txtStegoOutput
            // 
            this.txtStegoOutput.Location = new System.Drawing.Point(50, 350);
            this.txtStegoOutput.Name = "txtStegoOutput";
            this.txtStegoOutput.ReadOnly = true;
            this.txtStegoOutput.Size = new System.Drawing.Size(400, 22);
            this.txtStegoOutput.TabIndex = 5;
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(400, 50);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(75, 23);
            this.btnEncrypt.TabIndex = 6;
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(500, 50);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(75, 23);
            this.btnDecrypt.TabIndex = 7;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // btnEncryptHide
            // 
            this.btnEncryptHide.Location = new System.Drawing.Point(50, 300);
            this.btnEncryptHide.Name = "btnEncryptHide";
            this.btnEncryptHide.Size = new System.Drawing.Size(128, 23);
            this.btnEncryptHide.TabIndex = 8;
            this.btnEncryptHide.Text = "Encrypt and Hide";
            this.btnEncryptHide.Click += new System.EventHandler(this.btnEncryptHide_Click);
            // 
            // btnExtractDecrypt
            // 
            this.btnExtractDecrypt.Location = new System.Drawing.Point(200, 300);
            this.btnExtractDecrypt.Name = "btnExtractDecrypt";
            this.btnExtractDecrypt.Size = new System.Drawing.Size(150, 23);
            this.btnExtractDecrypt.TabIndex = 9;
            this.btnExtractDecrypt.Text = "Extract and Decrypt";
            this.btnExtractDecrypt.Click += new System.EventHandler(this.btnExtractDecrypt_Click);
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Location = new System.Drawing.Point(454, 300);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(136, 23);
            this.btnLoadImage.TabIndex = 11;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.txtUserInput);
            this.Controls.Add(this.cmbShiftKey);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.txtStegoInput);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.txtImagePath);
            this.Controls.Add(this.txtStegoOutput);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.btnEncryptHide);
            this.Controls.Add(this.btnExtractDecrypt);
            this.Controls.Add(this.btnLoadImage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Encryption Steganography Tool";
            this.ResumeLayout(false);
            this.PerformLayout();
            //
            //
            //
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.progressBar.Location = new System.Drawing.Point(50, 400);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(400, 23);
            this.progressBar.TabIndex = 10;
            this.Controls.Add(this.progressBar);

        }
    }
}