﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace EncryptionSteganographyApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 25; i >= 1; i--)
            {
                cmbShiftKey.Items.Add(i);
            }
            cmbShiftKey.SelectedIndex = 0; // Optional..


            Panel panel1 = new Panel();
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 300);
            panel1.Location = new Point(50, 50);
            this.Controls.Add(panel1);

          
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            progressBar.Value = 0; // Reset ProgressBar

            string text = txtUserInput.Text;
            int shift = int.Parse(cmbShiftKey.Text);
            txtOutput.Text = CaesarCipher.Encrypt(text, shift);
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            progressBar.Value = 0; // Reset 

            string text = txtUserInput.Text;
            int shift = int.Parse(cmbShiftKey.Text);
            txtOutput.Text = CaesarCipher.Decrypt(text, shift);
        }

        private void btnEncryptHide_Click(object sender, EventArgs e)
        {
            progressBar.Value = 0; // reset

            // Check if text input or image path is empty
            if (string.IsNullOrEmpty(txtStegoInput.Text) || string.IsNullOrEmpty(txtImagePath.Text))
            {
                MessageBox.Show("Please enter text to hide and select an image.");
                return;
            }

            // Validation
            if (!System.IO.File.Exists(txtImagePath.Text))
            {
                MessageBox.Show("Invalid image file path. Please load a valid image.");
                return;
            }

            try
            {
                // Load the image from the specified path
                Bitmap image = new Bitmap(txtImagePath.Text);
                string text = txtStegoInput.Text;

                // Hide text in the image
                Bitmap stegoImage = LSBSteganography.HideText(text, image);

                // Save the stego image
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PNG Image|*.png";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    stegoImage.Save(saveFileDialog.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    MessageBox.Show("Text hidden and image saved successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }

            progressBar.Value = 0;
            progressBar.Step = 1;
            progressBar.Maximum = 100;

            for (int i = 0; i <= 100; i++)
            {
                System.Threading.Thread.Sleep(10); // Simulate processing delay
                progressBar.PerformStep();
            }
            MessageBox.Show("Operation Completed!");
        }

        private void btnExtractDecrypt_Click(object sender, EventArgs e)
        {
            progressBar.Value = 0; // Reset ProgressBar

            Bitmap image = new Bitmap(txtImagePath.Text);
            string extractedText = LSBSteganography.ExtractText(image);

            txtStegoOutput.Text = extractedText;
            MessageBox.Show("Text extracted successfully!");
        }






        private Bitmap loadedImage;

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.bmp)|*.png;*.jpg;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtImagePath.Text = openFileDialog.FileName;
                MessageBox.Show("Image loaded successfully!");
            }
        }

        private void btnSaveImage_Click(object sender, EventArgs e)
        {
            if (loadedImage != null)
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PNG Image|*.png";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    loadedImage.Save(saveFileDialog.FileName);
                    MessageBox.Show("Encrypted image saved successfully!");
                }
            }
            else
            {
                MessageBox.Show("No image loaded or encrypted yet.");
            }
        }


        private void BtnExample_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Button was clicked!");
        }


    }
}