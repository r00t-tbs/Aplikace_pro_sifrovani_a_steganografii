﻿namespace EncryptionSteganographyApp
{
    public static class CaesarCipher
    {
        public static string Encrypt(string input, int shift)
        {
            return ShiftText(input, shift);
        }

        public static string Decrypt(string input, int shift)
        {
            return ShiftText(input, -shift);
        }

        private static string ShiftText(string input, int shift)
        {
            char[] buffer = input.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                char letter = buffer[i];
                if (char.IsLetter(letter))
                {
                    //ASCII indexation
                    char offset = char.IsUpper(letter) ? 'A' : 'a';
                    buffer[i] = (char)(((letter + shift - offset + 26) % 26) + offset);
                }
            }
            return new string(buffer);
        }
    }
}